package br.ufsc.eficem.eficemrio2018;

import android.os.Handler;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.IOException;

public class Chronometer1 {

    private static boolean isRunning;
    private Handler handler;
    private long initialTime;
    private final long MILLIS_IN_SEC = 1000L;
    private final int SECS_IN_MIN = 60;
    private TextView timeTextView,regressiveTimeTextView,lapTimeTextView;
    private Integer tempoBanco,tempoDeProva,regressiveTime,tempoVolta,somaTempo = 0;
   // final Carro carro = new Carro();
    //final GuardaArquivo guardaArquivo = new GuardaArquivo();



    public void setSomaTempo(Integer somaTempo) {
        this.somaTempo = somaTempo;
    }

    public Integer getTempoBanco() {
        return tempoBanco;
    }

    public void iniciaCronometro(RunningActivity runningActivity, Competicao competicao){
        handler = new Handler();
        isRunning = true;

        initialTime = System.currentTimeMillis();

        timeTextView = runningActivity.getTimeTextView();

        regressiveTimeTextView = runningActivity.getRegressiveTimeTextView();
        lapTimeTextView = runningActivity.getLapTimeTextView();

        handler.postDelayed(runnable, MILLIS_IN_SEC);
        tempoDeProva = Integer.valueOf(competicao.tempoDeProva);
    }

    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (isRunning) {
                long totalTime = (System.currentTimeMillis() - initialTime) / MILLIS_IN_SEC;
                tempoBanco = Integer.valueOf((int) totalTime);

                regressiveTime = tempoDeProva - tempoBanco;
                tempoVolta = tempoBanco - somaTempo;

                timeTextView.setText(String.format("%02d:%02d", totalTime / SECS_IN_MIN, totalTime % SECS_IN_MIN));
                regressiveTimeTextView.setText(String.format("%02d:%02d", regressiveTime / SECS_IN_MIN, regressiveTime % SECS_IN_MIN));
                lapTimeTextView.setText(String.format("%02d:%02d", tempoVolta / SECS_IN_MIN, tempoVolta % SECS_IN_MIN));



                handler.postDelayed(runnable, MILLIS_IN_SEC);
               // try {
                 //   guardaArquivo.salvaArquivo(carro);
                //} catch (IOException e) {
                  //  e.printStackTrace();
              //  }
            }
        }
    };
}
